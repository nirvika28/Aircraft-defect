# aircraft_skin_defects > 2023-05-01 12:21pm
https://universe.roboflow.com/ddiisc/aircraft_skin_defects

Provided by a Roboflow user
License: CC BY 4.0

This is a custom dataset created with manually clicked photographs of 3 different types of aircraft. The images are labelled for 5 different classes of surface defects on aircraft skin viz.

Crack
Dent
Scratch
Paint-peel-off
Missing-head (rivets, fastners, screws etc)
The dataset consists of total 372 images with distribution as follows:
Hawker Hunter - 276
HT2 - 70
Pushpak - 76

The dataset has been created for implementation as part of M.Tech (AI) thesis of the author at IISc, Bengaluru.

Note: The author couldn't find any detailed / relevant dataset available on the internet. Thus, this dataset is aimed as a repo of such images for future use as well. Please feel free to use it for your own custom model or you can use the pretrained model. Kindly cite requisite credits to the author while using it.